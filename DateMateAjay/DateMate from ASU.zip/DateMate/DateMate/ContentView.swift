//
//  ContentView.swift
//  DateMate
//
//  Created by Ajay Yadav on 10/11/24.
//

import SwiftUI

struct ContentView: View {
    // Moved the UIApplicationDelegateAdaptor outside the body for proper scope
    
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}



#Preview {
    ContentView()
}
