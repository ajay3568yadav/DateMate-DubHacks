//
//  AuthenticationView.swift
//  DateMate
//
//  Created by ajay Yadav on 10/11/24.
//

import SwiftUI
import RiveRuntime


struct AuthenticationView: View {
    @Binding var showModal: Bool // Binding to control modal visibility

    var body: some View {
        VStack(spacing: 20) {
            Spacer() // Push content to the center

            // Title
            Text("Sign in")
                .font(.system(size: 30, weight: .bold))

            // Subtitle
            Text("Get ready for your date")
                .font(.system(size: 16))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)

            // Email TextField
            TextField("Email", text: .constant(""))
                .padding()
                .background(RoundedRectangle(cornerRadius: 12).stroke(Color.gray, lineWidth: 1))
                .overlay(
                    Image(systemName: "envelope.fill")
                        .foregroundColor(.pink)
                        .padding(.leading, 8),
                    alignment: .leading
                )
                .padding(.horizontal, 30)

            // Password TextField
            SecureField("Password", text: .constant(""))
                .padding()
                .background(RoundedRectangle(cornerRadius: 12).stroke(Color.gray, lineWidth: 1))
                .overlay(
                    Image(systemName: "lock.fill")
                        .foregroundColor(.pink)
                        .padding(.leading, 8),
                    alignment: .leading
                )
                .padding(.horizontal, 30)

            // Sign In Button
            Button(action: {
                print("Sign In Tapped")
            }) {
                Text("Sign In")
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 25)
                            .fill(Color.pink)
                    )
                    .padding(.horizontal, 30)
            }

            // OR Divider
            Text("OR")
                .foregroundColor(.gray)

            // Social Login Options
            HStack(spacing: 20) {
                Image(systemName: "envelope.fill")
                    .foregroundColor(.black)
                    .frame(width: 50, height: 50)
                    .background(Circle().stroke(Color.black, lineWidth: 1))

                Image(systemName: "apple.logo")
                    .foregroundColor(.black)
                    .frame(width: 50, height: 50)
                    .background(Circle().stroke(Color.black, lineWidth: 1))

                Image(systemName: "globe")
                    .foregroundColor(.pink)
                    .frame(width: 50, height: 50)
                    .background(Circle().stroke(Color.pink, lineWidth: 1))
            }

            Spacer()

            // Close Button
            Button(action: {
                withAnimation {
                    showModal = false // Dismiss the modal with animation
                }
            }) {
                Image(systemName: "xmark")
                    .foregroundColor(.black)
                    .frame(width: 40, height: 40)
                    .background(Circle().fill(Color.white))
                    .shadow(radius: 5)
            }
            .padding(.bottom, 20)
        }
        .frame(maxWidth: .infinity)
        .frame(height: UIScreen.main.bounds.height * 0.6) // Control modal height
        .background(
            RoundedRectangle(cornerRadius: 30)
                .fill(Color.white)
                .shadow(radius: 10)
        )
        .padding(.horizontal, 10)
    }
}
