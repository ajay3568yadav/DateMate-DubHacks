//
//  AuthenticationManager.swift
//  DateMate
//
//  Created by ajay Yadav on 10/11/24.
//

import Foundation

final class AuthenticationManager{
    static let shared = AuthenticationManager()
    private init(){
        
    }
}
